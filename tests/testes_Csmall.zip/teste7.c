int main()
{
  int x = 0, y = 10;
  float a = 1.3, z;
  if (x < y)
    x = ((a - 1.3) * y );
  else if (x + y)
    y = ((2 * x) / y);
  else if (x > y)
    x = a;
  if(x != a)
  {
    x = 3504;
    z = 23.4;
  }
}
