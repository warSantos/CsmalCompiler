int main()
{
  int a = 1, b = 0;
  if (a + b - a - b)
    a = 10;
  print(a);
  print(b);
}
