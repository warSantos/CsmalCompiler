int main()
{
  int x = 0, y = 1, z;
  x = 3 + 2 - x;
  while (x >= y)
  {
    y = y + 1;
    z = z + 2;
  }
}
