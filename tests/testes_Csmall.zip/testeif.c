int main()
{
  int c = 100;
  if ( (c!= 1) || (c == 1)){
    c = c - 2 / 4 * 10;
  }
  print(c);
}
