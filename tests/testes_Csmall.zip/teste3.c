int main()
{
  int x = 1, y = 1 || 2 + 3*4 && 1;
  float z = x + y;
  print(x);
  print(y);
  print(z);
  while (x < y + z * 9 - 3)
  {
    int b = 1, c=2, d = 5;
    if (d == c && b + c)
        b = 1;
    else if (b <= c)
    {
      if (x < 4)
        x = 0;
    }
    else
    {
      int j = 10;
      while (j > 3)
        j = j - 1;
      {
        c = c < b;
        d = d >= c;
      }
    }
    print(b);
    print(c);
    print(d);    
    float k;
    x = x + 10;
  }
  int z;
  float x, y;
}
