int main(){
  int i, j, cont = 0;
  for (i=0; i < 2*(4 - 3/5); i = i + 1)
      for (j=10; j > 0; j = j - 1)
            cont = cont + 1;
}
